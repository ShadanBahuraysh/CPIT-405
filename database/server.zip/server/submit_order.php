<?php
//============================= PHPMailer Setup =============================
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // Include PHPMailer autoloader

//============================= Headers for CORS and JSON =============================
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: *");

//============================= Connect to MySQL Database =============================
$conn = new mysqli("localhost", "root", "mysql", "second_chance");

if ($conn->connect_error) {
    echo json_encode(["message" => "Connection failed"]);
    exit();
}

//============================= Receive JSON Input =============================
$data = json_decode(file_get_contents("php://input"), true);

if (!$data) {
    echo json_encode(["message" => "No data received"]);
    exit();
}

//============================= Extract Data from Request =============================
$name       = $data['name'] ?? '';
$email      = $data['email'] ?? '';
$address    = $data['address'] ?? '';
$phone      = $data['phone'] ?? '';
$productId  = $data['productId'] ?? 0;
$order_code = "SC-" . rand(100000, 999999); // Generate random order code

//============================= Insert Order into Database =============================
$stmt = $conn->prepare("INSERT INTO orders (product_id, name, email, address, phone, order_code) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("isssss", $productId, $name, $email, $address, $phone, $order_code);

if ($stmt->execute()) {

    //============================= Send Confirmation Email =============================
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'secondchance.it22@gmail.com';    //  email
        $mail->Password   = 'tdbpaityojstibmc';               //  App Password
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;

        $mail->setFrom('secondchance.it22@gmail.com', 'Second Chance');
        $mail->addAddress($email, $name);

        $mail->isHTML(true);
        $mail->Subject = "Your Order Confirmation - $order_code";// The message sent after the request made
        $mail->Body    = "
            <h2>Thank you, $name!</h2>
            <p>Your order has been received successfully.</p>     
            <p><strong>Order Code:</strong> $order_code</p>
            <p><strong>Address:</strong> $address</p>
            <p><strong>Phone:</strong> $phone</p>
            <p>We will contact you soon regarding delivery.</p>
            <br>
            <em>Second Chance Team</em>
        ";

        $mail->send();
        echo json_encode(["message" => "Order submitted and email sent successfully"]);

    } catch (Exception $e) {
        echo json_encode(["message" => "Order saved, but email failed: {$mail->ErrorInfo}"]);
    }

} else {
    echo json_encode(["message" => "Error saving order"]);
}
?>
