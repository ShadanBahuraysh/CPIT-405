<?php
//============================= Headers for  JSON =============================
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: *");

//============================= Connect to MySQL Database =============================
$conn = new mysqli("localhost", "root", "mysql", "second_chance");

if ($conn->connect_error) {
    echo json_encode(["message" => "Connection failed"]);
    exit();
}

//============================= Receive Order Code from JSON Request =============================
$data = json_decode(file_get_contents("php://input"), true);
$order_code = $data['order_code'] ?? '';

if (empty($order_code)) {
    echo json_encode(["message" => "Order code is required"]);
    exit();
}

//============================= Query Order from Database =============================
$stmt = $conn->prepare("SELECT * FROM orders WHERE order_code = ?");
$stmt->bind_param("s", $order_code);
$stmt->execute();
$result = $stmt->get_result();

//============================= Return Result as JSON =============================
if ($order = $result->fetch_assoc()) {
    echo json_encode(["found" => true, "order" => $order]);
} else {
    echo json_encode(["found" => false]);
}
?>
