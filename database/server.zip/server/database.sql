
-- ==============================
-- Database Creation for Second Chance Project
-- ==============================

-- Create database if it doesn't already exist
CREATE DATABASE IF NOT EXISTS second_chance;

-- Use the created database
USE second_chance;

-- ==============================
-- Orders Table
-- Stores all customer orders submitted via the form
-- ==============================
CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,          -- Unique ID for each order
  product_id INT,                             -- ID of the product (from API)
  name VARCHAR(100) NOT NULL,                 -- Full name of the customer
  email VARCHAR(100) NOT NULL,                -- Customer email
  address TEXT NOT NULL,                      -- Delivery address
  phone VARCHAR(20) NOT NULL,                 -- Phone number
  order_code VARCHAR(50) NOT NULL UNIQUE,     -- Unique code used for tracking order
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP -- Timestamp of order submission
);
